# M. Jordan Group LLC — Standalone Site (No Build)

Single-file HTML site ready to deploy.

## Deploy fast

### Netlify Drop (easiest)
1) Go to https://app.netlify.com/drop
2) Drag this folder (or the ZIP)
3) Get a public URL instantly

### GitHub Pages
1) Create a repo, upload files
2) Settings → Pages → Source: Deploy from branch, Folder: /root
3) Wait ~1 minute for the public link
